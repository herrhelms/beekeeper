open -a Finder ~/.beekeeper/sessions/
