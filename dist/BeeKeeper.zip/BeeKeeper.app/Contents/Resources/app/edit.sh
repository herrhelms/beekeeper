open -e ~/.beekeeper/projects
